package com.example.ju.coach.modele;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.ju.coach.outils.MesOutils;
import com.example.ju.coach.outils.MySQLiteOpenHelper;

import java.util.Date;

public class AccessLocal {

    //Propriétés
    private String nomBase = "bdCoach.sqlite";
    private Integer versionBase = 1;
    private MySQLiteOpenHelper accesBD;
    private SQLiteDatabase bd;

    /**
     *
     * @param context
     */
    public AccessLocal(Context context) {
        this.accesBD = new MySQLiteOpenHelper(context, nomBase, versionBase);
    }

    public void ajout(Profil profil){
       this.bd = accesBD.getWritableDatabase();
       String req = "insert into profil (dateMesure, poids, taille, age, sexe) values";
       req += "(\"" + profil.getDateMesure() + "\"," + profil.getPoids() + "," + profil.getTaille() +
               "," + profil.getAge() + "," + profil.getSexe() + ")";
       bd.execSQL(req);
    }

    public Profil recupDernier(){
        Profil profil = null;
        this.bd = accesBD.getReadableDatabase();
        String req = "select * from profil";
        Cursor curseur = bd.rawQuery(req, null);
        curseur.moveToLast();

        // contrôle s'il y a bien au moins une ligne
        if (!curseur.isAfterLast()){
            // récupération des informations du dernier profil
            Date dateMesure = MesOutils.convertStringToDate(curseur.getString(0));
            Log.d("date", "*************************conversion : " + dateMesure);
            Integer poids = curseur.getInt(1);
            Integer taille = curseur.getInt(2);
            Integer age = curseur.getInt(3);
            Integer sexe = curseur.getInt(4);

            //Création de l'objet profil
            profil = new Profil(dateMesure, poids, taille, age, sexe);
        }
        // fermeture du curseur
        curseur.close();
        // retourne le profil
        return profil;
    }
}
