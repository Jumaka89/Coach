package com.example.ju.coach.outils;

/**
 * Created by emds on 07/08/2015.
 */
public interface AsyncResponse {
    void processFinish(String output);
}
